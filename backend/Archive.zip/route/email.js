const express = require('express');
const app = express();

const mongoose = require('mongoose');
const { admin, editor } = require('./super');
const HagereEmail = new mongoose.model(
  'HagereEmail',
  new mongoose.Schema({
    email: {
      type: String,
      required: true,
    },
  })
);

app.post(
  '/add-subscriber',

  async (req, res) => {
    console.log('called');
    const subscriber = new HagereEmail({
      email: req.body.email,
    });

    const result = await subscriber.save();
    res.send(result);
  }
);
app.post('/get-subscribers', async (req, res) => {
  const subscriber = await HagereEmail.find();
  res.send(subscriber);
});

app.post(
  '/delete-subscriber',
  admin,
  async (req, res) => {
    const subscriber = await HagereEmail.deleteOne(
      {
        _id: req.body.id,
      }
    );
    res.send(subscriber);
  }
);
module.exports = app;
