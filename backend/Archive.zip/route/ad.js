const express = require('express');
const path = require('path');
const app = express();
const fs = require('fs');
const multer = require('multer');

const mongoose = require('mongoose');
////////////////////////////////////////////////////////////////
// const { auth } = require('./authentication');
const { admin, editor } = require('./super');
////////////////////////////////////////////////////////////////
const HagereFeatureAd = new mongoose.model(
  'HagereFeatureAd',
  new mongoose.Schema({
    featureAd: {
      type: String,
      required: true,
    },
  })
);
const HagereAd = new mongoose.model(
  'HagereAd',
  new mongoose.Schema({
    ad: {
      type: String,
      required: true,
    },
  })
);
const storage = multer.diskStorage({
  destination: function (req, res, cb) {
    cb(null, path.join(__dirname, '..', 'ads'));
  },
  filename: function (req, file, cb) {
    const now = new Date().toISOString();
    const date = now.replace(/:/g, '-');
    cb(null, date + file.originalname);
  },
});
const upload = multer({ storage: storage });

app.post(
  '/ad-feature-ad',
  editor,
  upload.single('adFeatureImage'),
  async (req, res) => {
    if (!req.file) {
      return res
        .status(400)
        .send('Plese send a feature ad image');
    }

    const ad = new HagereFeatureAd({
      featureAd: req.file.filename,
    });
    const result = await ad.save();
    res.send(result);
  }
);

app.post('/get-feature-ad', async (req, res) => {
  const ad = await HagereFeatureAd.findOne();

  console.log(ad);
  res.send(ad);
});

app.post(
  '/edit-feature-ad',
  editor,
  upload.single('adFeatureImage'),
  async (req, res) => {
    console.log('inside ', req.user);
    if (!req.file || !req.body.oldFeatureImage) {
      return res.status(400).send('bad request');
    }

    const file = path.join(
      __dirname,
      '..',
      'ads',
      req.body.oldFeatureImage
    );
    console.log('test', req.file);

    const feature = await HagereFeatureAd.updateOne(
      {
        $set: { featureAd: req.file.filename },
      }
    );
    if (feature.nModified) {
      fs.unlink(file, (err) => {
        if (err) res.status(500).send(err);
        else {
          return res.send(feature);
        }
      });
      // res.send(feature);
    } else {
      res.send(feature);
    }
  }
);

app.post(
  '/delete-feature-ad',
  editor,
  async (req, res) => {
    if (!req.body.oldFeatureImage) {
      return res.status(400).send('bad request');
    }
    const file = path.join(
      __dirname,
      '..',
      'ads',
      req.body.oldFeatureImage
    );
    const feature = await HagereFeatureAd.deleteOne();
    if (feature.n) {
      fs.unlink(file, (err) => {
        if (err) res.status(500).send(err);
        else {
          return res.send(feature);
        }
      });
    } else {
      res.send('Unable to delete');
    }
  }
);

// adds////////////////////////////////////////////////////////////////////////////////////
app.post(
  '/ad',
  editor,
  upload.single('adImage'),
  async (req, res) => {
    if (!req.file) {
      return res.status(400).send('bad request');
    }
    const ad = new HagereAd({
      ad: req.file.filename,
    });
    const result = await ad.save();
    res.send(result);
  }
);

app.post('/get-ads', async (req, res) => {
  const ad = await HagereAd.find();
  console.log("sendingggggggggggggggggggggggggggg");
  res.status(200).send(ad);
});

app.post(
  '/edit-ad',
  editor,
  upload.single('newAdImage'),
  async (req, res) => {
    if (
      !req.file ||
      !req.body.id ||
      !req.body.oldFeatureImage
    ) {
      return res.status(400).send('bad request');
    }
    const ad = await HagereAd.findOne({
      _id: req.body.id,
    });
    console.log(ad);
    const file = path.join(
      __dirname,
      '..',
      'ads',
      ad.Ad
    );
    const feature = await HagereAd.updateOne(
      {
        _id: req.body.id,
      },
      {
        $set: { Ad: req.file.filename },
      }
    );
    if (feature.nModified) {
      fs.unlink(file, (err) => {
        if (err) res.status(500).send(err);
        else {
          return res.send(feature);
        }
      });
      // res.send(feature);
    } else {
      res.send(feature);
    }
  }
);

app.post(
  '/delete-ad',
  editor,
  async (req, res) => {
    console.log(req.body);
    if (!req.body.id) {
      return res.status(400).send('bad request');
    }
    const ad = await HagereAd.findOne({
      _id: req.body.id,
    });

    if (ad) {
      const file = path.join(
        __dirname,
        '..',
        'ads',
        ad.ad
      );
      const feature = await HagereAd.deleteOne({
        _id: req.body.id,
      });
      if (feature.n) {
        fs.unlink(file, (err) => {
          if (err) res.status(500).send(err);
          else {
            return res.send(feature);
          }
        });
      } else {
        res.send('Unable to delete');
      }
    } else {
      res.send('file not found');
    }
  }
);

module.exports = app;
