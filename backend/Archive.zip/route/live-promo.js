const express = require('express');
const path = require('path');
const app = express();
const fs = require('fs');
const multer = require('multer');

const mongoose = require('mongoose');
const { admin, editor } = require('./super');
const HagereLivePormo = new mongoose.model(
  'HagereLivePromo',
  new mongoose.Schema({
    promoImage: {
      type: String,
      required: true,
    },
  })
);

// new Date().toISOString()
const storage = multer.diskStorage({
  destination: function (req, res, cb) {
    cb(
      null,
      path.join(__dirname, '..', 'uploads')
    );
  },
  filename: function (req, file, cb) {
    const now = new Date().toISOString();
    const date = now.replace(/:/g, '-');
    cb(null, date + file.originalname);
  },
});
const upload = multer({ storage: storage });

app.post(
  '/add-live-promo', editor,
  upload.single('promoImage'),
  async (req, res) => {
    const promo = new HagereLivePormo({
      promoImage: req.file.filename,
    });
    const result = await promo.save();
    res.send(result);
  }
);

app.post('/get-live-promo', async (req, res) => {
  const ad = await HagereLivePormo.findOne();

  console.log(ad);
  res.send(ad);
});

app.post(
  '/edit-live-promo', editor,
  upload.single('promoImage'),
  async (req, res) => {
    const file = path.join(
      __dirname,
      '..',
      'uploads',
      req.body.oldPromoImage
    );
    const promo = await HagereLivePormo.updateOne(
      {
        $set: { promoImage: req.file.filename },
      }
    );
    if (promo.nModified) {
      fs.unlink(file, (err) => {
        if (err) res.status(500).send(err);
        else {
          return res.send(promo);
        }
      });
      // res.send(feature);
    } else {
      res.send(promo);
    }
  }
);

module.exports = app;
