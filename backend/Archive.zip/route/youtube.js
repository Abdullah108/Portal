const express = require('express');

const app = express();

const mongoose = require('mongoose');
const { admin, editor } = require('./super');
const HagereYoutube = new mongoose.model(
  'HagereYoutube',
  new mongoose.Schema({
    youtube: {
      type: String,
      required: true,
    },
  })
);

app.post(
  '/add-youtube', admin,

  async (req, res) => {
    const youtube = new HagereYoutube({
      youtube: req.body.youtube,
    });
    const result = await youtube.save();
    res.send(result);
  }
);

app.post('/edit-youtube', admin, async (req, res) => {
  let oldYoutube = await HagereYoutube.updateOne(
    {
      _id: req.body.id,
    },
    {
      $set: {
        youtube: req.body.youtube,
      },
    }
  );
  if (oldYoutube.nModified) {
    res.send(oldYoutube);
  } else {
    res
      .status(500)
      .send('New Slogan Same as Current Slogan');
  }
});

app.post('/get-youtube', async (req, res) => {
  let oldYoutube = await HagereYoutube.find();
  res.send(oldYoutube);
});

module.exports = app;
