const express = require('express');
const path = require('path');
const app = express();

const fs = require('fs');

const multer = require('multer');

const mongoose = require('mongoose');
const { admin, editor } = require('./super');
// hagere gallaey schema

const HagereGallarys = new mongoose.model(
  'HagereGallary',
  new mongoose.Schema({
    catagoryEn: {
      type: String,
      required: true,
    },
    catagoryAm: {
      type: String,
      required: true,
    },
    images: [
      {
        type: String,
        required: true,
      },
    ],
  })
);

// mlter for adding dates as a prefix from file name

const storage = multer.diskStorage({
  destination: function (req, res, cb) {
    cb(
      null,
      path.join(__dirname, '..', 'uploadgallery')
    );
  },
  filename: function (req, file, cb) {
    const now = new Date().toISOString();
    const date = now.replace(/:/g, '-');
    cb(null, date + file.originalname);
  },
});

// giving storage to multer

const uploadgallery = multer({
  storage: storage,
});

// schema for number of images on gallary

var cpUpload = uploadgallery.fields([
  { name: 'gallaryImages', maxCount: 10 },
]);

/////////////////
// var cpUpload1 = uploadgallery.fields([
//   { name: 'gallaryImages', maxCount: 10 },
// ]);
/////////////////
// creating gallary

app.post(
  '/add-gallary', editor,
  cpUpload,
  async (req, res) => {
    let images = [];

    req.files.gallaryImages.map((image) =>
      images.push(image.filename)
    );

    const gallary = new HagereGallarys({
      catagoryEn: req.body.catagoryEn,
      catagoryAm: req.body.catagoryAm,
      images: images,
    });
    const result = await gallary.save();
    res.send(result);
  }
);

// getting gallaries from database

app.post('/get-gallary', async (req, res) => {
  const gallary = await HagereGallarys.find({
    _id: req.body.id,
  });

  res.send(gallary);
});
app.post(
  '/get-all-gallarys',
  async (req, res) => {
    const gallary = await HagereGallarys.find();

    res.send(gallary);
  }
);

// deliting image from a given gallary

app.post(
  '/delete-image', editor,
  async (req, res) => {
    console.log("bodyyyyyyyyyyy", req.body);
    const file = path.join(
      __dirname,
      '..',
      'uploadgallery',
      req.body.image
    );

    let oldGallary = await HagereGallarys.findById(
      req.body.id
    );
    console.log("hereeeeeeeeeeeeeeeeeeeeeee", oldGallary);
    if (!oldGallary) {
      return res.status(404).send('Gallary Not Found');
    }

    console.log("22222222222 hereeeeeeeeeeeeeeeeeeeeeee", oldGallary);
    let index = oldGallary.images.indexOf(
      req.body.image
    );
    let deleted = false;
    console.log("index", index);
    if (index >= 0) {
      console.log("inside index");
      oldGallary.images.splice(index, 1);
      fs.unlink(file, (err) => {
        if (err) {
          deleted = false;
          console.log(err);

        }
        else { deleted = true; }
      });
    }

    const response = await oldGallary.save();
    if (deleted) {
      res.send(response);
    } else {
      return res.status(500).send("failed");
    }

  }
);

// change specific image on a gallary

app.post(
  '/change-image', editor,
  uploadgallery.single('newImage'),
  async (req, res) => {
    const file = path.join(
      __dirname,
      '..',
      'uploadgallery',
      req.body.oldImage
    );

    let oldGallary = await HagereGallarys.updateOne(
      {
        _id: req.body.id,
        images: req.body.oldImage,
      },
      {
        $set: { 'images.$': req.file.filename },
      }
    );
    if (oldGallary.nModified) {
      fs.unlink(file, (err) => {
        if (err) res.status(500).send(err);
        else res.send('removed');
      });
      res.send(oldGallary);
    } else {
      res
        .status(500)
        .send(`Error image not Modified`);
    }
  }
);

// change Gallary catagory

app.post('/change-catagory', editor, async (req, res) => {
  // console.log('cat en', req);
  let oldGallary = await HagereGallarys.updateOne(
    {
      _id: req.body.id,
    },
    {
      $set: {
        catagoryEn: req.body.catagoryEn,
        catagoryAm: req.body.catagoryAm,
      },
    }
  );
  if (oldGallary.nModified) {
    res.send(oldGallary);
  } else {
    res.status(500).send('Error server error');
  }
});

// adding new images to a gallary

app.post(
  '/add-images-to-gallary', editor,
  uploadgallery.array('gallaryImages', 10),
  async (req, res) => {
    let images = [];
    console.log('gallery', req.files);
    req.files.map(
      (image) => images.push(image.filename)
      // console.log('test', image)
    );
    console.log('images', images);
    let oldGallary = await HagereGallarys.updateOne(
      {
        _id: req.body.id,
      },
      {
        $push: { images: { $each: [...images] } },
      }
    );

    if (oldGallary.nModified) {
      res.send(oldGallary);
    } else {
      res.status(500).send('Error server error');
    }
  }
);

// exporting

module.exports = app;
